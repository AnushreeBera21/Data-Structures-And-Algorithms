package Chapter2;
/*
Implement a function which takes as input an array and a key and updates
the array so that all occurrences of the input key have been removed and the remaining
elements have been shifted left to fill the emptied indices. Return the number of
remaining elements. There are no requirements as to the values stored beyond the
last valid element.
 */
public class RemoveAllOccureneceOfAnElement {

}
