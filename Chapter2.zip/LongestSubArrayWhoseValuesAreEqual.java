package Chapter2;
/*
Write a program that takes an array of integers and finds the length of a
longest subarray all of whose entries are equal.
 */
public class LongestSubArrayWhoseValuesAreEqual {

}
