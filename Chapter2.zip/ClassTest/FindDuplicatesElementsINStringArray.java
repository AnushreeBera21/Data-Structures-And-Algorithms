package Chapter2.ClassTest;

public class FindDuplicatesElementsINStringArray {
    public static void main(String[] args) {
        String []ar = {"hello","bye","lion","cat","bye","lion","tiger","hello","dog"};
        for(int i = 0;i < ar.length;i++){
            for(int j = i+1;j < ar.length;j++){
                if(ar[i].equalsIgnoreCase(ar[j])) {
                    System.out.println(ar[i]);
                    break;
                }

            }
        }
    }
}
