package Chapter2.ClassTest;

public class TargetSumOfTwoNumbers {
    public static void main(String[] args) {
        int []ar = {2,3,6,11,7,9,4,15,12,24,25};
        int target = 14;
        for(int i = 0;i < ar.length;i++){
            for(int j = i+1;j < ar.length;j++){
                if(ar[i] + ar[j] == target) {
                    System.out.println(ar[i] + "," + ar[j]);
                    break;
                }
            }
        }
    }
}
