package Chapter2.ClassTest;

public class IntersectionOfTwoArrays {
    public static void main(String[] args) {
        int []ar1 = {3,2,5,7,6,14,18,21,56,34,23};
        int []ar2 = {18,21,56,7,1,0,-3,35,-12,45,2,3};
//        naive approach
//        hashset can be used
        System.out.println("Intersection : ");
        for(int i : ar1){
            for(int j : ar2){
                if(i == j) {
                    System.out.print(i+" ");
                    break;
                }
            }
        }

    }
}
