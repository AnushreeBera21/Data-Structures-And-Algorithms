package Chapter2.ClassTest;

public class SeperateZeroesFromNonZeroesInArray {
    public static void main(String[] args) {
        int []ar = {3,0,2,-4,8,0,0,0,3,4,23,0,0,21,0,0};
        int j = 0,temp;
        for(int i = 0 ;i < ar.length;i++){
            if(ar[i] == 0){
                temp = ar[i];
                ar[i] = ar[j];
                ar[j] = temp;
                ++j;
            }
        }

        for(int i : ar)
            System.out.print(i+" ");

    }
}
