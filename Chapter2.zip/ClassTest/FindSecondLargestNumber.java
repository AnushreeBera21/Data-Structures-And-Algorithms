package Chapter2.ClassTest;

public class FindSecondLargestNumber {
    public static void main(String[] args) {
        int []ar = {3,3,3,3};
        secondLargest(ar);
    }

    public static void secondLargest(int[] ar){
        int first =  Integer.MIN_VALUE,second = Integer.MIN_VALUE;
        for (int j : ar) {
            if (j > first) {
                second = first;
                first = j;
            } else if (j > second && j < first)
                second = j;
        }

        if(second == Integer.MIN_VALUE)
            System.out.println("No second largest value");
        else
            System.out.println("Second largest value is "+second);
    }
}
