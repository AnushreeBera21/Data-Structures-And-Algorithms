package Chapter2;
/*
Write a program that computes the maximum profit that can be made by buying and
selling a share at most twice. The second buy must be made on another date after the
first sale.
 */
public class MaxProfitByBuyingTwice {
}
